/*
* 基类
* Created by panyinglong(503940285@qq.com).
* DateTime: 2017/10/27 20：07
*/

class GameObject {
    constructor(){
        
    }
}