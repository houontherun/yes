/*
* 游戏控制器
* Created by panyinglong(503940285@qq.com).
* DateTime: 2017/10/27 20：05
*/

class GameController extends GameObject{
}